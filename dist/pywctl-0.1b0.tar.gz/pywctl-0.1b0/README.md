# pywctl
A utility to connect you, using python, to iwd, using iwctl, in ash. Made specifically for snakeware.

# Dependencies
`python3`
`pip3`
`iwd`
`git`
an internet connection (unless you're on snakeware, then it's included for MY FORK.)

# Installation
This will clone the repo and install the module. THIS IS NOT READY FOR INSTALLATION YET.

`git clone https://github.com/SorrowEater/pywctl.git`
`cd pywctl`
`pip3 install .`
